var express = require('express');
var router = express.Router();

/* GET home page. */
let index = require('.../controllers/landing')
router.get('/', landing.get_landing);
router.post('/', landing.submit_lead);
router.get('/leads', landing.show_leads);

module.exports = router;
